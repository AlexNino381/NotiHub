# NotiHub

Sistema de notificaciones multicanal (correo, SMS y mensajería) con canales simulados.
Proyecto del parcial de Patrones de Diseño, en Java.

## Requisitos
- JDK 17 o superior
- Maven (incluido en NetBeans)

## Compilar y probar
```
mvn test
```

## Ejecutar la demostración
```
mvn compile exec:java
```
(O desde NetBeans: clic derecho sobre `Principal.java` > Run File.)

## Funcionalidades implementadas
- Modelo: usuarios con canales preferidos, mensajes y plantillas con marcadores.
- Canales simulados con interfaces distintas (correo, SMS, mensajería) integrados con el patrón Adapter.
- Fachada `CentralNotificaciones` como único punto de entrada para enviar mensajes.

(Se irá actualizando a medida que avance el proyecto.)
