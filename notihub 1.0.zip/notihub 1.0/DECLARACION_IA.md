# Declaración de uso de herramientas de inteligencia artificial

Herramienta utilizada: Claude (Anthropic).

| Fecha | Parte del proyecto | Para qué se usó | Qué hice yo |
|---|---|---|---|
| 2026-11-16 | Código base (modelo, canales, fachada) y pruebas | Generar una primera versión del código | (Analizar y comprender como se vera el modelo base del programa completo) |

Todo el código, los diagramas y los textos incluidos en este repositorio los puedo explicar.
